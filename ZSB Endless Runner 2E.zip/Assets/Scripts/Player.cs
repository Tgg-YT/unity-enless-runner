﻿using UnityEngine;

public class Player : MonoBehaviour
{
    [SerializeField] private float movementSpeed = 8f;
    // public (widoczny w Inspectorze, widoczny dla innych skryptow (klas)
    // private (niewidoczny w Inspectorze, niewidoczny dla innych skryptow
    // [SerializeField] private (widoczny w Inspectorze, niewidoczny dla innych skryptow)
    // [HideInInspector] public (niewidoczny w Inspectorze, widoczny dla innych skryptow)

    private void Update()
    {
        // old: 1 unit per frame
        // 1 unit per second
        transform.Translate(Vector3.forward * movementSpeed * Time.deltaTime);
    }
}
